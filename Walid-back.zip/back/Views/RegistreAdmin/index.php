<?php
    include 'C:\xampp\htdocs\WEB\Site\Controller\ClientC.php';
    if(isset($_POST["submit"]))
    {   
        if ($_POST['email'] && $_POST['pass'])
        {  
          $a=new AdminC();
          $user = $a->verifyEmailAdmin($_POST['email']);
          if ($user != true)
          {
            $NouvAd = new Admin($_POST['email'] ,$_POST['pass']);
            $last_id = $a->ajouteradmin($NouvAd);
            $cookie_name = "id";
            $cookie_value = $last_id;
            setcookie($cookie_name, $cookie_value, strtotime( '+30 days' ),"/",'localhost');
            header("Location:../TABLEADMINS/index.php");
          }
        }
        else
        {
            echo '<script>alert("SOMETHING MISSING")</script>';
        }      
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Mukta:wght@200&display=swap');
  </style>
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
</head>
<body>
<div class="signupFrm">
    <form method="POST" action="" class="form">
      <h1 class="title">Admin Sign up</h1>

      <div class="inputContainer">
        <input type="text" class="input" placeholder="a" name="email">
        <label for="" class="label">Email</label>
      </div>

      <div class="inputContainer">
        <input type="password" class="input" placeholder="a" name="pass">
        <label for="" class="label">Password</label>
      </div>

      <input name="submit" type="submit" class="submitBtn" value="Sign up">
    </form>
  </div>
  <script src="node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
</body>
</html>