<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
<div class="container flex">
    <div class="flex_content flex2">
        <h2>Basic</h2>
        <h4>Free</h4>
        <span>3,000 monthly visitors</span>
        <ul>
            <li>Limited Reports</li>
            <li>Unlimited projects</li>
            <li>Data storage for 1 year</li>
        </ul>
        <button>
            Start Now
        </button>
    </div>
    <div class="flex_content">
        <h2>Pro</h2>
        <h4>$19 / month</h4>
        <span>10,000 monthly visitors</span>
        <ul>
            <li>Unlimited Reports</li>
            <li>15-days free trial</li>
            <li>Data storage for 3 year</li>
        </ul>
        <button>
            Try it
        </button>
    </div>
</div>
<footer>
    SOURCE: <a
        href="https://uidesigndaily.com/posts/sketch-pricing-card-price-table-dark-theme-ui-day-1108">click
        here</a>
</footer>

<script src="index.js" type="text/javascript"></script>
</body>
</html>