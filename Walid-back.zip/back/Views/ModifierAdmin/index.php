<?php
include 'C:\xampp\htdocs\WEB\Site\Controller\ClientC.php';
$a=new AdminC();
$numAd = (int)$_GET["id1"];
//chercher le client dans bd
$forum = $a->getAdminById($numAd);
//modifier
if(isset($_POST["submit"]))
{
    $a->ModifierAdmin( $numAd, $_POST['email'] ,$_POST['password']);
    header("Location: ../TABLEADMINS/index.php");
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <form method="POST">
            <div class="login-box">
              <h1>Modify</h1>
              <div class="textbox">
                <i class="fas fa-user"></i>
                <input type="email" placeholder="Email" name="email" value= "<?= $forum['email']; ?>">
              </div>

              <div class="textbox">
                <i class="fas fa-lock"></i>
                <input type="text" placeholder="Password" name="password" value= "<?= $forum['password']; ?>">
              </div>

              <input type="submit" class="btn" value="Update" name="submit">
            </div>
</form>
<div class="backbu">
				<a href="../TABLEADMINS/index.php" class="btn">
					<span class="text">Text</span>
					<span class="flip-front">Go Back</span>
					<span class="flip-back">Back</span>
				</a>
		</div>
  </body>
</html>
