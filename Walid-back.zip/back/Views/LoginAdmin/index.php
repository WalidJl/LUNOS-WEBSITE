<?php
    include 'C:\xampp\htdocs\WEB\Site\Controller\ClientC.php';
    if(isset($_POST["submit"]))
    {   
        if ($_POST['email'] && $_POST['pass'])
        {  
          $a=new AdminC();
          $user = $a->verifyEmailAdmin($_POST['email']);
          if ($user != true)
          {
            $NouvAd = new Admin($_POST['email'] ,$_POST['pass']);
            $last_id = $a->ajouteradmin($NouvAd);
            $cookie_name = "id";
            $cookie_value = $last_id;
            setcookie($cookie_name, $cookie_value, strtotime( '+30 days' ),"/",'localhost');
            header("Location:../TABLEADMINS/index.php");
          }
        }
        else
        {
            echo '<script>alert("SOMETHING MISSING")</script>';
        }      
    }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login Client</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
  

    <div class="center">
      <h1>Add Admin</h1>
      <form method="POST">
        <div class="txt_field">
          <input name="email" type="text" >
          <span></span>
          <label>Email</label>
        </div>
        <div class="txt_field">
          <input name="pass" type="password" >
          <span></span>
          <label>Password</label>
        </div>
        <input type="submit" value="Login" name="submit">
        <div class="signup_link">
          
        </div>
      </form>
      
    </div>
    <div class="but">
      <a href="../TABLEADMINS/index.php" class="btn"><span>Go  Back</span><em></em></a>
      </div>
  </body>
</html>
