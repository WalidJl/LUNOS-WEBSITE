<?php
	include 'C:\xampp\htdocs\WEB\Site\Controller\ClientC.php';
  $m=new ClientC();
  $utilisateurM = $m->MaleNumber();
  $utilisateurF = $m->FemaleNumber();
  $utilisateur = $m->AccountNumber();
?>
<html>
<head>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
   google.charts.load('current', {'packages':['corechart']});
</script>
<link rel="stylesheet" href="style.css" />

</head>
<body>


<div class="container flex">
    <div class="flex_content-flex2">
        <h2>Clinets Numbers : <?=(int)$utilisateur["nb"]?></h2>
        <br>
        <h2>Male Numbers : <?=(int)$utilisateurM["total"]?></h2>
        <h2>Female Numbers :<?=(int)$utilisateurF["total"]?></h2>

    </div>
    <div class="flex_content">
        <h2>Gender Graphs</h2>
        
        
        <div id="chart_div">

                                  <script>
                                  // Callback that draws the pie chart
                                  google.charts.setOnLoadCallback(draw_my_chart);
                                  function draw_my_chart() {
                                    var data = new google.visualization.DataTable();
                                    data.addColumn('string', 'language');
                                    data.addColumn('number', 'Nos');
                                  //for(i = 0; i < my_2d.length; i++)
                                  //data.addRow([my_2d[i][0], parseInt(my_2d[i][1])]);
                                  data.addRows([['MALE',<?=(int)$utilisateurM["total"]?>],
                                        ['FEMALE',<?=(int)$utilisateurF["total"]?>]]);
                                  // above row adds the JavaScript two dimensional array data into required chart format
                                  var options = {title:'Statistical',
                                                  width:600,
                                                  height:400,
                                              };

                                    // Instantiate and draw the chart
                                    var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
                                    chart.draw(data, options);
                                  }
                                  </script>

                </div>    
    </div>
</div>
<footer>
    BACK: <a
        href="../TABLECLIENT/index.php">Click here</a>
</footer>

<script src="index.js" type="text/javascript"></script>
</body>
</html>



